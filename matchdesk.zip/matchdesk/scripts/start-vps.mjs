#!/usr/bin/env node
import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const server = [".output/server/index.mjs", ".output/server/index.js"]
  .map((p) => join(root, p))
  .find((p) => existsSync(p));

process.env.PORT ||= "3000";
process.env.HOST ||= "127.0.0.1";
process.env.NITRO_PORT ||= process.env.PORT;
process.env.NITRO_HOST ||= process.env.HOST;

if (server) {
  await import(pathToFileURL(server).href);
} else {
  const child = spawn(
    process.execPath,
    ["scripts/with-app-env.mjs", "vite", "preview", "--host", "127.0.0.1", "--port", "3000"],
    { cwd: root, stdio: "inherit", env: process.env },
  );
  child.on("exit", (code) => process.exit(code ?? 1));
}
