# Matchdesk

Eén aanvraag. Eén installateur.

Live zetten op de VPS (één commando, als root):

```bash
curl -fsSL https://raw.githubusercontent.com/koenferdi/Agent/matchdesk/deploy/vps.sh | sudo bash
```

Daarna staat [www.getmatchdesk.nl](https://www.getmatchdesk.nl) op deze versie. Opnieuw uitvoeren = bijwerken.
