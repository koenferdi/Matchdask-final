import type { AppUser } from "@/lib/auth/use-current-user";

const OWNER_EMAILS = new Set([
  "info@getmatchdesk.nl",
  "koenferdi@gmail.com",
  "koen@getmatchdesk.nl",
  "koen.ferdi@gmail.com",
]);

export function isOwner(user: AppUser | null | undefined) {
  if (!user) return false;
  const email = user.primaryEmail?.trim().toLowerCase() ?? "";
  const name = user.displayName?.trim().toLowerCase() ?? "";
  if (OWNER_EMAILS.has(email)) return true;
  if (email.endsWith("@getmatchdesk.nl")) return true;
  if (email.startsWith("koen") && email.includes("@")) return true;
  if (name.startsWith("koen")) return true;
  return false;
}
