import { create } from "zustand";
import {
  type Lead,
  type Partner,
  type Product,
  type Term,
  loadWorkspace,
  saveWorkspace,
  newId,
  findPartnerFor,
  SEED_PARTNERS,
  type Subscriber,
} from "./matchdesk";

export type Draft = {
  product: Product;
  postcode: string;
  city: string;
  address: string;
  term: Term | "";
  name: string;
  email: string;
  phone: string;
  consent: boolean;
};

const emptyDraft = (): Draft => ({
  product: "Zonnepanelen",
  postcode: "",
  city: "",
  address: "",
  term: "",
  name: "",
  email: "",
  phone: "",
  consent: false,
});

type Store = {
  ready: boolean;
  leads: Lead[];
  partners: Partner[];
  subscribers: Subscriber[];
  activeLeadId?: string;
  reportPaid: boolean;
  draft: Draft;
  hydrate: () => void;
  persist: () => void;
  setDraft: (patch: Partial<Draft>) => void;
  resetDraft: () => void;
  submitLead: () => Lead;
  requestMatch: (leadId: string) => void;
  bookAppointment: (leadId: string, date: string, time: string) => void;
  cancelAppointment: (leadId: string) => void;
  submitPartner: (partner: Omit<Partner, "id" | "status" | "quality">) => Partner;
  setPartnerStatus: (id: string, status: Partner["status"]) => void;
  setLeadStatus: (id: string, status: Lead["status"]) => void;
  markReportPaid: () => void;
  subscribe: (email: string, name: string) => void;
};

function persistNow(get: () => Store) {
  const s = get();
  saveWorkspace({
    leads: s.leads,
    partners: s.partners,
    subscribers: s.subscribers,
    activeLeadId: s.activeLeadId,
    reportPaid: s.reportPaid,
  });
}

export const useMatchdesk = create<Store>((set, get) => ({
  ready: false,
  leads: [],
  partners: SEED_PARTNERS,
  subscribers: [],
  reportPaid: false,
  draft: emptyDraft(),
  hydrate: () => {
    const ws = loadWorkspace();
    set({
      ready: true,
      leads: ws.leads,
      partners: ws.partners,
      subscribers: ws.subscribers,
      activeLeadId: ws.activeLeadId,
      reportPaid: Boolean(ws.reportPaid),
    });
  },
  persist: () => persistNow(get),
  setDraft: (patch) => set((s) => ({ draft: { ...s.draft, ...patch } })),
  resetDraft: () => set({ draft: emptyDraft() }),
  submitLead: () => {
    const d = get().draft;
    const lead: Lead = {
      id: newId("MD"),
      product: d.product,
      postcode: d.postcode,
      city: d.city,
      address: d.address,
      term: (d.term || "Ik oriënteer me nog") as Term,
      name: d.name,
      email: d.email,
      phone: d.phone,
      consent: d.consent,
      status: "Nieuw",
      createdAt: new Date().toISOString(),
    };
    set((s) => ({ leads: [lead, ...s.leads], activeLeadId: lead.id }));
    persistNow(get);
    return lead;
  },
  requestMatch: (leadId) => {
    const { leads, partners } = get();
    const lead = leads.find((l) => l.id === leadId);
    if (!lead) return;
    const partner = findPartnerFor(lead, partners);
    set((s) => ({
      leads: s.leads.map((l) =>
        l.id === leadId
          ? { ...l, status: partner ? "Gematcht" : "Nieuw", partnerId: partner?.id }
          : l,
      ),
    }));
    persistNow(get);
  },
  bookAppointment: (leadId, date, time) => {
    set((s) => ({
      leads: s.leads.map((l) =>
        l.id === leadId
          ? { ...l, appointment: { date, time, status: "Aangevraagd" } }
          : l,
      ),
    }));
    persistNow(get);
  },
  cancelAppointment: (leadId) => {
    set((s) => ({
      leads: s.leads.map((l) =>
        l.id === leadId && l.appointment
          ? { ...l, appointment: { ...l.appointment, status: "Geannuleerd" } }
          : l,
      ),
    }));
    persistNow(get);
  },
  submitPartner: (partner) => {
    const next: Partner = {
      ...partner,
      id: newId("P"),
      status: "Te beoordelen",
      quality: 0,
    };
    set((s) => ({ partners: [next, ...s.partners] }));
    persistNow(get);
    return next;
  },
  setPartnerStatus: (id, status) => {
    set((s) => ({
      partners: s.partners.map((p) => (p.id === id ? { ...p, status } : p)),
    }));
    persistNow(get);
  },
  setLeadStatus: (id, status) => {
    set((s) => ({
      leads: s.leads.map((l) => (l.id === id ? { ...l, status } : l)),
    }));
    persistNow(get);
  },
  markReportPaid: () => {
    set({ reportPaid: true });
    persistNow(get);
  },
  subscribe: (email, name) => {
    const clean = email.trim().toLowerCase();
    if (!clean) return;
    set((s) => {
      if (s.subscribers.some((x) => x.email === clean)) return s;
      return {
        subscribers: [
          { email: clean, name: name.trim(), createdAt: new Date().toISOString() },
          ...s.subscribers,
        ],
      };
    });
    persistNow(get);
  },
}));
