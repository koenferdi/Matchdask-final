export type Article = {
  slug: string;
  title: string;
  kicker: string;
  excerpt: string;
  date: string;
  read: string;
  image: string;
  body: string[];
};

export const ARTICLES: Article[] = [
  {
    slug: "een-installateur-in-plaats-van-drie-offertes",
    title: "Waarom één installateur beter werkt dan drie offertes",
    kicker: "Matching",
    excerpt:
      "Meer offertes voelen veilig. In de praktijk kost het tijd, vaagheid en een installateur die weet dat hij moet concurreren op prijs — niet op vakwerk.",
    date: "12 september 2026",
    read: "4 min",
    image: "/higgsfield/installer.webp",
    body: [
      "Wie zonnepanelen of een thuisbatterij overweegt, krijgt vaak hetzelfde advies: vraag drie offertes aan. Het klinkt zorgvuldig. Het leidt meestal tot drie gesprekken, drie aannames over je woning en drie prijzen die je niet kunt vergelijken.",
      "Matchdesk werkt anders. Jij doet één aanvraag. Wij kijken naar postcode, vakgebied, beoordeelde kwaliteit en beschikbare capaciteit. Daarna gaat je aanvraag naar één passende installateur — niet naar een veiling.",
      "Die installateur weet dat hij niet hoeft te undercutten. Jij weet dat je niet vijf keer hetzelfde verhaal hoeft te doen. Het eerste gesprek kan over de woning gaan, niet over wie het goedkoopst durft te beloven.",
      "Geen match is ook een antwoord. Als er in jouw regio geen partner past, blijft de aanvraag open. We sturen niets door tot jij om een match vraagt.",
    ],
  },
  {
    slug: "wat-een-thuisbatterij-wel-en-niet-doet",
    title: "Wat een thuisbatterij wél doet — en wat niet",
    kicker: "Thuisbatterij",
    excerpt:
      "Een batterij is geen verdienmodel op zich. Het is een buffer voor je eigen stroom. Dat verschil voorkomt teleurstelling in het eerste gesprek.",
    date: "4 september 2026",
    read: "5 min",
    image: "/higgsfield/battery.webp",
    body: [
      "Een thuisbatterij bewaart stroom die je overdag opwekt, zodat je die ’s avonds kunt gebruiken. Dat is het hele punt. Geen magie, geen garantie op lagere jaarkosten, geen vervanging van het net.",
      "Wat hij niet doet: hij maakt van een ongunstig dak geen goudmijn. Hij rekent niet je terugleverkosten weg. En hij vervangt geen goed gesprek over verbruik, omvormer, netaansluiting en of panelen überhaupt passen.",
      "Daarom begint Matchdesk bij de woning, niet bij het product. In de woningscan kijken we naar regio, dakrichting en wat je wilt. Het rapport is oriëntatie — geen installatieadvies en geen besparingsbelofte.",
      "Neem dat rapport mee naar jouw ene installateur. Laat hém rekenen met jouw meter, jouw dak en jouw wensen. Dat is zijn vak. Ons vak is hem zorgvuldig kiezen.",
    ],
  },
  {
    slug: "zo-bereid-je-het-eerste-gesprek-voor",
    title: "Zo bereid je het eerste gesprek voor",
    kicker: "Woningscan",
    excerpt:
      "Het verschil tussen een vaag gesprek en een scherpe eerste offerte zit zelden in de prijs. Het zit in wat jij al weet over je woning.",
    date: "21 augustus 2026",
    read: "3 min",
    image: "/higgsfield/solar.webp",
    body: [
      "Een goed eerste gesprek duurt geen uur langer. Het begint beter. Je installateur hoeft dan niet te gissen naar je verbruik, je termijn of of je alleen panelen wilt of ook een batterij.",
      "Zet klaar: je postcode, een recente jaarafrekening of slimme-meterstand, of je auto laadt, en wanneer je wilt starten. Een paar foto’s van het dak helpen meer dan een lange mail.",
      "De Matchdesk-woningscan bundelt dat tot een Fit-rapport. Geen belofte, wel een gedeeld startpunt. Je neemt het mee naar de installateur die bij jouw aanvraag past.",
      "Plan daarna in je portaal een moment. Jij ziet de status. De installateur ook. Geen bcc naar drie bedrijven, geen ‘wie belt het eerst’.",
    ],
  },
  {
    slug: "wat-matchdesk-niet-belooft",
    title: "Wat Matchdesk niet belooft",
    kicker: "Heldere kaders",
    excerpt:
      "Geen lagere energierekening-garantie. Geen installatie. Geen veiling. Als we dat niet scherp houden, belooft een ander het wél — en jij betaalt de teleurstelling.",
    date: "8 september 2026",
    read: "3 min",
    image: "/higgsfield/home-desktop-poster.png",
    body: [
      "Matchdesk is een bemiddelingsplatform. Wij kiezen één passende installateur. Wij installeren niet, we geven geen technisch advies over jouw dak, en we tekenen geen overeenkomst met jou voor het werk.",
      "We beloven geen besparing in euro’s of kWh. Die hangt af van jouw woning, tarieven, teruglevering en hoe de installatie wordt uitgevoerd. Dat hoort bij het gesprek met de installateur — niet bij een website.",
      "We beloven ook geen beschikbaarheid in elke postcode. Past er niemand, dan blijft de aanvraag open. Liever geen match dan een verkeerde.",
      "Wat we wél doen: zorgvuldig selecteren op werkgebied, vakgebied, beoordeelde kwaliteit en capaciteit. En pas doorzetten als jij om een match vraagt.",
    ],
  },
  {
    slug: "exclusief-proof-wat-je-koopt",
    title: "Exclusief-proof: wat je als installateur wél koopt",
    kicker: "Voor bedrijven",
    excerpt:
      "Early-bird €149 is geen advertentiebudget en geen garantie op klussen. Het is een jaarlijkse keuring: KvK, reviews, respons. Daarna een badge — of niet.",
    date: "1 september 2026",
    read: "4 min",
    image: "/higgsfield/installer.webp",
    body: [
      "Exclusief-proof is de kwaliteitscheck voor Actieve Matchdesk-partners. Je betaalt voor de keuring, niet voor een plaats in een veiling. We kijken naar KvK, reviews en of je reageert.",
      "Slaagt de check, dan mag je de badge ‘Exclusief partner gecontroleerd door Matchdesk’. Zakt hij, dan geen badge. We kopen je geen leads.",
      "De commissie blijft los: eerste gewonnen klus €0, daarna 10% van de dealwaarde (max. €400 bij panelen, €600 bij batterij of combi). Dat spreek je vooraf af. De huiseigenaar betaalt Matchdesk niets.",
      "Early-bird €149 is voor wie nu instapt. Geen belofte op volume. Wel een helder keurmerk voor wie 1:1-aanvragen in het eigen werkgebied wil, zonder drie concurrenten in cc.",
    ],
  },
];

export function getArticle(slug: string) {
  return ARTICLES.find((a) => a.slug === slug);
}

export function relatedArticles(slug: string, n = 2) {
  return ARTICLES.filter((a) => a.slug !== slug).slice(0, n);
}
