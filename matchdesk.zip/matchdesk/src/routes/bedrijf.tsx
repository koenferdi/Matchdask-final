import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageIntro, Wrap } from "@/components/site-shell";
import { PortalGate } from "@/components/portal-gate";
import { useMatchdesk } from "@/lib/store";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/bedrijf")({ component: BedrijfPage });

function BedrijfPage() {
  return (
    <PortalGate role="bedrijf">
      <Bedrijf />
    </PortalGate>
  );
}

function Bedrijf() {
  const user = useCurrentUser();
  const { leads, partners, setLeadStatus } = useMatchdesk();
  const email = user?.primaryEmail?.toLowerCase();
  const mine =
    (email ? partners.find((p) => p.email.toLowerCase() === email && !p.example) : undefined) ??
    (user?.isDevFallback ? partners.find((p) => !p.example) : undefined);
  const assigned = leads.filter((l) => l.partnerId === mine?.id || (l.status !== "Nieuw" && mine));

  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <PageIntro kicker="Bedrijfsportaal" title={mine ? mine.name : "Jouw werkgebied."}>
          Exclusieve aanvragen, capaciteit en commissie-overzicht. Eén lead, één installateur.
        </PageIntro>
        {!mine ? (
          <Button asChild>
            <Link to="/aanmelden">Meld je bedrijf aan</Link>
          </Button>
        ) : (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="rounded-lg border border-line bg-white p-5">
              <small className="text-[11px] uppercase tracking-wider text-muted">Status</small>
              <strong className="mt-1 block text-xl">{mine.status}</strong>
            </div>
            <div className="rounded-lg border border-line bg-white p-5">
              <small className="text-[11px] uppercase tracking-wider text-muted">Werkgebied</small>
              <strong className="mt-1 block text-xl">{mine.prefixes.map((p) => `${p}xx`).join(", ")}</strong>
            </div>
            <div className="rounded-lg border border-line bg-white p-5">
              <small className="text-[11px] uppercase tracking-wider text-muted">Capaciteit</small>
              <strong className="mt-1 block text-xl">{mine.capacity} projecten</strong>
            </div>
            <section className="rounded-lg border border-line bg-white p-6 lg:col-span-3">
              <h2 className="text-2xl">Aanvragen</h2>
              {assigned.length === 0 ? (
                <p className="mt-3 text-sm text-muted">Nog geen exclusieve aanvragen in jouw gebied. Nieuwe matches verschijnen hier.</p>
              ) : (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[640px] text-left text-sm">
                    <thead className="text-xs uppercase tracking-wider text-muted">
                      <tr>
                        <th className="py-2">Aanvraag</th>
                        <th>Product</th>
                        <th>Locatie</th>
                        <th>Status</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {assigned.map((l) => (
                        <tr key={l.id} className="border-t border-line">
                          <td className="py-3 font-semibold">{l.name}</td>
                          <td>{l.product}</td>
                          <td>
                            {l.postcode} {l.city}
                          </td>
                          <td>{l.status}</td>
                          <td>
                            {l.status === "Gematcht" ? (
                              <Button size="sm" variant="ghost" onClick={() => setLeadStatus(l.id, "Offerte")}>
                                Offerte starten
                              </Button>
                            ) : null}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </div>
        )}
      </Wrap>
    </main>
  );
}
