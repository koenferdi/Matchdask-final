import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro, Wrap } from "@/components/site-shell";
import { NewsletterForm } from "@/components/newsletter-form";
import { ARTICLES } from "@/lib/blog";

export const Route = createFileRoute("/blog")({
  component: Blog,
  head: () => ({
    meta: [{ title: "Inzicht — Matchdesk" }, { name: "description", content: "Korte stukken over matching, thuisbatterijen en het eerste gesprek met je installateur." }],
  }),
});

function Blog() {
  const [featured, ...rest] = ARTICLES;
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <PageIntro kicker="Inzicht" title="Korte stukken. Geen ruis.">
          Matching, batterijen en het eerste gesprek — geschreven zoals we matchen: één ding tegelijk, zonder belofte die een installateur niet kan waarmaken.
        </PageIntro>
        <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-8">
            {featured ? (
              <article className="overflow-hidden rounded-lg border border-line bg-white">
                <img src={featured.image} alt={featured.title} className="h-72 w-full object-cover" />
                <div className="p-6 md:p-8">
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-teal">
                    {featured.kicker} · {featured.read}
                  </p>
                  <h2 className="mt-3 font-display text-[clamp(1.8rem,3vw,2.6rem)]">
                    <Link to="/blog/$slug" params={{ slug: featured.slug }} className="hover:text-teal">
                      {featured.title}
                    </Link>
                  </h2>
                  <p className="mt-3 text-lg text-muted">{featured.excerpt}</p>
                  <p className="mt-4 text-xs text-muted">{featured.date}</p>
                </div>
              </article>
            ) : null}
            {rest.map((a) => (
              <article key={a.slug} className="overflow-hidden rounded-lg border border-line bg-white">
                <img src={a.image} alt={a.title} className="h-48 w-full object-cover" loading="lazy" />
                <div className="p-6">
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-teal">
                    {a.kicker} · {a.read}
                  </p>
                  <h2 className="mt-3 font-display text-3xl">
                    <Link to="/blog/$slug" params={{ slug: a.slug }} className="hover:text-teal">
                      {a.title}
                    </Link>
                  </h2>
                  <p className="mt-3 text-muted">{a.excerpt}</p>
                  <p className="mt-4 text-xs text-muted">{a.date}</p>
                </div>
              </article>
            ))}
          </div>
          <aside className="h-fit rounded-lg border border-line bg-white p-6 lg:sticky lg:top-28">
            <h2 className="font-display text-2xl">Nieuwsbrief</h2>
            <p className="mt-2 mb-5 text-sm text-muted">
              Een paar keer per jaar. Over wonen, energie en 1:1-matching.
            </p>
            <NewsletterForm />
          </aside>
        </div>
      </Wrap>
    </main>
  );
}
