import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro, Wrap } from "@/components/site-shell";
import { CONTACT } from "@/lib/matchdesk";

export const Route = createFileRoute("/voorwaarden")({ component: Voorwaarden });

function Voorwaarden() {
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap className="max-w-3xl">
        <PageIntro kicker="Voorwaarden · versie 1.1 · 8 september 2026" title="Voorwaarden voor huiseigenaren">
          Wat je van Matchdesk mag verwachten als bemiddelingsplatform.
        </PageIntro>
        <article className="space-y-6 text-sm leading-7 text-muted [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:text-ink">
          <h2>1. Wie we zijn</h2>
          <p>Matchdesk is een bemiddelingsplatform, KvK {CONTACT.kvk}. Wij voeren zelf geen installaties uit en leveren geen producten.</p>
          <h2>2. Wat Matchdesk doet</h2>
          <p>Je dient een aanvraag in. Wij koppelen die aan precies één aangesloten installateur in jouw regio. Is er niemand beschikbaar, dan laten we je dat weten.</p>
          <h2>3. Geen overeenkomst tot installatie</h2>
          <p>De overeenkomst voor product en installatie sluit je uitsluitend met de installateur. Matchdesk is daar geen partij in.</p>
          <h2>4. Kosten</h2>
          <p>De bemiddeling is voor jou kosteloos. Wij ontvangen commissie van de installateur, uitsluitend als de klus tot stand komt.</p>
          <h2>5. Geen resultaatgarantie</h2>
          <p>Wij garanderen geen offerte, prijs, beschikbaarheid of planning.</p>
          <p>
            Partnervoorwaarden voor installateurs:{" "}
            <Link to="/voorwaarden-installateurs" className="text-teal">
              lees de installateursvoorwaarden
            </Link>
            .
          </p>
        </article>
      </Wrap>
    </main>
  );
}
