import { createFileRoute, Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PageIntro, Wrap } from "@/components/site-shell";
import { PortalGate } from "@/components/portal-gate";
import { findPartnerFor } from "@/lib/matchdesk";
import { useMatchdesk } from "@/lib/store";
import { isOwner } from "@/lib/owner";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/beheer")({ component: BeheerPage });

function BeheerPage() {
  return (
    <PortalGate>
      <OwnerOnly>
        <Beheer />
      </OwnerOnly>
    </PortalGate>
  );
}

function OwnerOnly({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <main className="bg-paper py-16">
        <Wrap>
          <div className="h-40 animate-pulse rounded-lg bg-line/60" />
        </Wrap>
      </main>
    );
  }
  if (!isOwner(user)) {
    return (
      <main className="bg-paper py-16 text-ink">
        <Wrap>
          <PageIntro kicker="Beheer" title="Dit deel is alleen voor Koen.">
            Het Matchdesk-beheer is geen klant- of bedrijfportaal. Je kunt hier verder met je eigen woning of je bedrijf.
          </PageIntro>
          <div className="flex flex-wrap gap-3">
            <Button asChild>
              <Link to="/klant">Naar klantportaal</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link to="/bedrijf">Naar bedrijfsportaal</Link>
            </Button>
          </div>
        </Wrap>
      </main>
    );
  }
  return children;
}

function Beheer() {
  const { leads, partners, subscribers, requestMatch, setPartnerStatus } = useMatchdesk();
  const open = leads.filter((l) => l.status === "Nieuw").length;
  const pendingPartners = partners.filter((p) => p.status === "Te beoordelen").length;

  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <PageIntro kicker="Beheer · alleen jij" title="Jij houdt het overzicht.">
          Beoordeel aanvragen, maak 1:1-matches, laat partners toe en zie wie de nieuwsbrief volgt. Dit scherm is niet zichtbaar voor klanten of installateurs.
        </PageIntro>
        <div className="mb-6 grid gap-4 sm:grid-cols-4">
          <Stat label="Open aanvragen" value={String(open)} />
          <Stat label="Partners te beoordelen" value={String(pendingPartners)} />
          <Stat label="Actieve partners" value={String(partners.filter((p) => p.status === "Actief").length)} />
          <Stat label="Nieuwsbrief" value={String(subscribers.length)} />
        </div>
        <section className="rounded-lg border border-line bg-white p-6">
          <h2 className="text-2xl">{leads.length} aanvragen</h2>
          <p className="text-sm text-muted">Eén installateur per aanvraag</p>
          {leads.length === 0 ? (
            <p className="mt-4 text-sm text-muted">Nog geen aanvragen. Nieuwe woningscans verschijnen hier.</p>
          ) : (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="text-xs uppercase tracking-wider text-muted">
                  <tr>
                    <th className="py-2">ID</th>
                    <th>Naam</th>
                    <th>Product</th>
                    <th>Postcode</th>
                    <th>Status</th>
                    <th>Match</th>
                  </tr>
                </thead>
                <tbody>
                  {leads.map((l) => {
                    const p = l.partnerId ? partners.find((x) => x.id === l.partnerId) : findPartnerFor(l, partners);
                    return (
                      <tr key={l.id} className="border-t border-line">
                        <td className="py-3 font-mono text-xs">{l.id}</td>
                        <td>{l.name}</td>
                        <td>{l.product}</td>
                        <td>{l.postcode}</td>
                        <td>{l.status}</td>
                        <td>
                          {l.status === "Nieuw" ? (
                            <Button size="sm" onClick={() => requestMatch(l.id)}>
                              Match {p?.name.split(" ")[0]}
                            </Button>
                          ) : (
                            p?.name ?? "—"
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <section className="mt-6 rounded-lg border border-line bg-white p-6">
          <h2 className="text-2xl">Installateurs</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {partners.map((p) => (
              <article key={p.id} className="rounded-md border border-line p-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-display text-lg">{p.name}</h3>
                  <span className="rounded-full bg-paper px-2 py-0.5 text-[11px] font-semibold text-teal">{p.status}</span>
                </div>
                <p className="mt-1 text-sm text-muted">{p.products.join(" · ")}</p>
                <p className="mt-2 text-xs text-muted">{p.prefixes.map((x) => `${x}xx`).join(", ")}</p>
                {p.status === "Te beoordelen" ? (
                  <Button size="sm" className="mt-3" onClick={() => setPartnerStatus(p.id, "Actief")}>
                    Toelaten
                  </Button>
                ) : null}
                {p.example ? <p className="mt-2 text-xs text-muted">Fictief voorbeeldbedrijf</p> : null}
              </article>
            ))}
          </div>
        </section>
        <section className="mt-6 rounded-lg border border-line bg-white p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-2xl">Nieuwsbrief</h2>
              <p className="text-sm text-muted">{subscribers.length} aanmeldingen · alleen jij ziet deze lijst</p>
            </div>
            {subscribers.length ? <CopyList emails={subscribers.map((s) => s.email)} /> : null}
          </div>
          {subscribers.length === 0 ? (
            <p className="mt-4 text-sm text-muted">Nog niemand ingeschreven.</p>
          ) : (
            <ul className="mt-4 divide-y divide-line text-sm">
              {subscribers.map((s) => (
                <li key={s.email} className="flex flex-wrap items-baseline justify-between gap-2 py-3">
                  <span>
                    <strong>{s.name || "—"}</strong> · {s.email}
                  </span>
                  <span className="text-xs text-muted">
                    {new Date(s.createdAt).toLocaleDateString("nl-NL")}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </Wrap>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-line bg-white p-5">
      <small className="text-[11px] uppercase tracking-wider text-muted">{label}</small>
      <strong className="mt-1 block font-display text-3xl tabular-nums">{value}</strong>
    </div>
  );
}

function CopyList({ emails }: { emails: string[] }) {
  const [done, setDone] = useState(false);
  return (
    <Button
      size="sm"
      variant="ghost"
      onClick={async () => {
        await navigator.clipboard.writeText(emails.join("\n"));
        setDone(true);
      }}
    >
      {done ? "Gekopieerd" : "Kopieer e-mails"}
    </Button>
  );
}
