import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Wrap } from "@/components/site-shell";
import { NewsletterForm } from "@/components/newsletter-form";
import { getArticle, relatedArticles } from "@/lib/blog";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const article = getArticle(params.slug);
    if (!article) throw notFound();
    return { article, related: relatedArticles(params.slug) };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.article.title ?? "Inzicht"} — Matchdesk` },
      { name: "description", content: loaderData?.article.excerpt ?? "" },
    ],
  }),
  component: Article,
});

function Article() {
  const { article, related } = Route.useLoaderData();
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap className="max-w-3xl">
        <Link to="/blog" className="inline-flex items-center gap-2 text-sm font-semibold text-teal">
          <ArrowLeft className="size-4" /> Alle stukken
        </Link>
        <p className="mt-8 text-xs font-semibold uppercase tracking-[0.14em] text-teal">
          {article.kicker} · {article.read} · {article.date}
        </p>
        <h1 className="mt-4 font-display text-[clamp(2rem,4vw,3.4rem)]">{article.title}</h1>
        <img src={article.image} alt={article.title} className="mt-8 h-72 w-full rounded-lg object-cover" />
        <div className="mt-10 space-y-5 text-lg leading-8 text-ink/90">
          {article.body.map((p) => (
            <p key={p}>{p}</p>
          ))}
        </div>
        {related.length ? (
          <div className="mt-14 border-t border-line pt-10">
            <h2 className="font-display text-2xl">Verder lezen</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {related.map((a) => (
                <Link
                  key={a.slug}
                  to="/blog/$slug"
                  params={{ slug: a.slug }}
                  className="rounded-lg border border-line bg-white p-5 hover:border-teal"
                >
                  <span className="text-xs font-semibold uppercase tracking-[0.14em] text-teal">{a.kicker}</span>
                  <strong className="mt-2 block font-display text-xl">{a.title}</strong>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-teal">
                    Lees verder <ArrowRight className="size-4" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        ) : null}
        <div className="mt-14 rounded-lg border border-line bg-white p-6">
          <h2 className="font-display text-2xl">Wil je dit soort stukken blijven lezen?</h2>
          <p className="mt-2 mb-5 text-sm text-muted">Geen wekelijkse storm. Wel het volgende inzicht.</p>
          <NewsletterForm />
        </div>
      </Wrap>
    </main>
  );
}
