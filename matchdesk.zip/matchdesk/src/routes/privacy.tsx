import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, Wrap } from "@/components/site-shell";
import { CONTACT } from "@/lib/matchdesk";

export const Route = createFileRoute("/privacy")({ component: Privacy });

function Privacy() {
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap className="max-w-3xl">
        <PageIntro kicker="Privacy · versie 1.2 · 12 september 2026" title="Privacybeleid">
          Welke persoonsgegevens Matchdesk verwerkt, waarom, op welke grondslag en hoe lang.
        </PageIntro>
        <article className="space-y-6 text-sm leading-7 text-muted [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:text-ink [&_strong]:text-ink">
          <p>
            Verwerkingsverantwoordelijke is Matchdesk, KvK {CONTACT.kvk}. Contact:{" "}
            <a className="text-teal" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>.
          </p>
          <h2>Wie is verantwoordelijk</h2>
          <p>
            Matchdesk brengt je aanvraag onder bij precies één installateur in jouw regio. Die installateur voert het werk uit en is jouw contractpartij.
          </p>
          <h2>Welke gegevens we verzamelen</h2>
          <p>Postcode, naam, e-mailadres, telefoonnummer, type installatie, gewenste termijn en eventueel een toelichting. Vul geen bijzondere of gevoelige gegevens in.</p>
          <h2>Doelen en grondslagen</h2>
          <p>
            Contactgegevens doorgeven aan één installateur gebeurt op grond van precontractuele maatregelen op jouw verzoek (art. 6 lid 1 sub b AVG). Telefonisch contact mag alleen met aparte, uitdrukkelijke toestemming.
          </p>
          <h2>Wie je gegevens ontvangt</h2>
          <p>Je gegevens gaan naar precies één installateur. We verkopen ze niet en geven ze niet door aan meerdere bedrijven.</p>
          <h2>Bewaartermijn</h2>
          <p>Aanvragen die nooit zijn gekoppeld, worden na twaalf maanden geanonimiseerd.</p>
          <h2>Je rechten</h2>
          <p>
            Je hebt recht op inzage, rectificatie, wissing, beperking, bezwaar, dataportabiliteit en het intrekken van toestemming. Stuur een verzoek naar {CONTACT.email}. Je kunt een klacht indienen bij de Autoriteit Persoonsgegevens.
          </p>
        </article>
      </Wrap>
    </main>
  );
}
