import { createFileRoute, Link } from "@tanstack/react-router";
import { Building2, Grid3x3, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageIntro, Wrap } from "@/components/site-shell";
import { isOwner } from "@/lib/owner";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/portalen")({ component: Portalen });

function Portalen() {
  const { user } = useCurrentUserState();
  const owner = isOwner(user);
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <div className="mb-4 rounded-md border border-line bg-white px-4 py-3 text-sm text-muted">
          Privé werkruimte · Wijzigingen blijven bewaard op dit apparaat · Er worden geen klanten of bedrijven benaderd zonder jouw actie
        </div>
        <PageIntro kicker="Eén platform. Jouw eigen plek." title="Welkom bij Mijn Matchdesk.">
          Bekijk het platform vanuit je woning of je bedrijf.
        </PageIntro>
        <div className={owner ? "grid gap-5 md:grid-cols-3" : "grid gap-5 md:grid-cols-2"}>
          <Role
            icon={Home}
            title="Voor mijn woning"
            body="Volg je aanvraag, bereid je gesprek voor en plan de volgende stap."
            cta="Open klantportaal"
            to="/klant"
          />
          <Role
            icon={Building2}
            title="Voor mijn bedrijf"
            body="Bekijk exclusieve aanvragen, je werkgebied en de planning."
            cta="Open bedrijfsportaal"
            to="/bedrijf"
          />
          {owner ? (
            <Role
              icon={Grid3x3}
              title="Mijn beheer"
              body="Alleen voor jou. Aanvragen, matches, partners en nieuwsbrief."
              cta="Open beheer"
              to="/beheer"
              dark
            />
          ) : null}
        </div>
      </Wrap>
    </main>
  );
}

function Role({
  icon: Icon,
  title,
  body,
  cta,
  to,
  dark,
}: {
  icon: typeof Home;
  title: string;
  body: string;
  cta: string;
  to: "/klant" | "/bedrijf" | "/beheer";
  dark?: boolean;
}) {
  return (
    <article className={dark ? "rounded-lg bg-night p-6 text-paper" : "rounded-lg border border-line bg-white p-6"}>
      <div className={dark ? "mb-4 flex size-11 items-center justify-center rounded-sm bg-deep text-mint" : "mb-4 flex size-11 items-center justify-center rounded-sm bg-paper text-teal"}>
        <Icon className="size-5" />
      </div>
      <h2 className="text-2xl">{title}</h2>
      <p className={dark ? "mt-2 text-sm text-mint/70" : "mt-2 text-sm text-muted"}>{body}</p>
      <Button asChild variant={dark ? "mint" : "default"} className="mt-6">
        <Link to={to}>{cta}</Link>
      </Button>
    </article>
  );
}
