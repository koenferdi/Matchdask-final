import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageIntro, Wrap } from "@/components/site-shell";
import { PortalGate } from "@/components/portal-gate";
import { useMatchdesk } from "@/lib/store";

export const Route = createFileRoute("/klant/afspraken")({ component: AfsprakenPage });

function AfsprakenPage() {
  return (
    <PortalGate>
      <Afspraken />
    </PortalGate>
  );
}

const TIMES = ["09:00", "10:30", "13:00", "15:00", "16:30"];

function Afspraken() {
  const { leads, bookAppointment, cancelAppointment } = useMatchdesk();
  const lead = leads[0];
  const [date, setDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().slice(0, 10);
  });
  const [time, setTime] = useState("10:30");

  if (!lead) {
    return (
      <main className="bg-paper py-16 text-ink">
        <Wrap>
          <PageIntro kicker="Afspraken" title="Eerst een aanvraag.">
            Maak een woningscan aan, daarna kun je hier een gesprek plannen.
          </PageIntro>
          <Button asChild>
            <Link to="/aanvragen">Start woningscan</Link>
          </Button>
        </Wrap>
      </main>
    );
  }

  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <PageIntro kicker="Afspraken" title="Plan een telefonisch gesprek.">
          Kies een moment. De installateur belt alleen als jij daar later om vraagt via een match.
        </PageIntro>
        {lead.appointment && lead.appointment.status !== "Geannuleerd" ? (
          <section className="max-w-xl rounded-lg border border-line bg-white p-6">
            <h2 className="text-2xl">Aangevraagde afspraak</h2>
            <p className="mt-2 text-muted">
              {lead.appointment.date} om {lead.appointment.time} · {lead.appointment.status}
            </p>
            <Button variant="ghost" className="mt-4" onClick={() => cancelAppointment(lead.id)}>
              Annuleren
            </Button>
          </section>
        ) : (
          <section className="max-w-xl rounded-lg border border-line bg-white p-6">
            <label className="block text-sm font-semibold">
              Datum
              <input type="date" className="field-input mt-1.5" value={date} onChange={(e) => setDate(e.target.value)} />
            </label>
            <fieldset className="mt-4">
              <legend className="text-sm font-semibold">Tijd</legend>
              <div className="mt-2 flex flex-wrap gap-2">
                {TIMES.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTime(t)}
                    className={t === time ? "rounded-sm bg-teal px-3 py-2 text-sm text-white" : "rounded-sm border border-line px-3 py-2 text-sm"}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </fieldset>
            <Button className="mt-6" onClick={() => bookAppointment(lead.id, date, time)}>
              Afspraak aanvragen
            </Button>
          </section>
        )}
      </Wrap>
    </main>
  );
}
