import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Battery, Home, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageIntro, Wrap } from "@/components/site-shell";
import { kwh } from "@/lib/matchdesk";

export const Route = createFileRoute("/tools")({ component: Tools });

function Tools() {
  const [panels, setPanels] = useState(10);
  const [yieldPer, setYieldPer] = useState(350);
  const [selfuse, setSelfuse] = useState(30);
  const [capacity, setCapacity] = useState(5);
  const [evening, setEvening] = useState(8);

  const total = panels * yieldPer;
  const used = Math.round((total * selfuse) / 100);
  const leftover = total - used;
  const cover = Math.min(100, Math.round((capacity / evening) * 100));

  const yieldLabel = useMemo(() => kwh(total), [total]);

  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap>
        <PageIntro kicker="Slimme tools" title="Een beetje inzicht. Een betere start.">
          Breng opwek, eigen gebruik en batterijcapaciteit bij elkaar — als voorbereiding, geen advies.
        </PageIntro>
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg border border-line bg-white p-6">
            <div className="mb-6 flex items-start justify-between">
              <div>
                <h2 className="text-2xl">Zelf meer stroom gebruiken</h2>
                <p className="text-sm text-muted">Verken je situatie met een eenvoudige schatting.</p>
              </div>
              <div className="flex size-11 items-center justify-center rounded-sm bg-mint text-teal">
                <Sun className="size-5" />
              </div>
            </div>
            <Range label="Aantal zonnepanelen" value={`${panels} panelen`} min={2} max={30} current={panels} onChange={setPanels} />
            <Range label="Opbrengst per paneel per jaar" value={`${yieldPer} kWh`} min={150} max={500} step={10} current={yieldPer} onChange={setYieldPer} />
            <Range label="Direct eigen gebruik" value={`${selfuse}%`} min={10} max={90} current={selfuse} onChange={setSelfuse} />
            <div className="mt-6 rounded-md bg-paper p-4">
              <small className="text-muted">Geschatte jaarlijkse opwek</small>
              <strong className="mt-1 block font-display text-4xl tabular-nums">{yieldLabel}</strong>
              <div className="my-4 flex items-center gap-3 text-teal">
                <Sun className="size-5" />
                <span className="h-px flex-1 bg-line" />
                <Home className="size-5" />
              </div>
              <p className="text-sm">
                {kwh(used)} direct gebruikt · {kwh(leftover)} over voor teruglevering of mogelijke opslag.
              </p>
            </div>
            <p className="mt-4 text-xs text-muted">
              Schatting op basis van jouw invoer. Seizoen, ligging, schaduw en gebruikspatroon zijn niet meegerekend.
            </p>
          </section>
          <section className="rounded-lg border border-line bg-white p-6">
            <div className="mb-6 flex items-start justify-between">
              <div>
                <h2 className="text-2xl">Wat kan een batterij opslaan?</h2>
                <p className="text-sm text-muted">Een eenvoudige capaciteitsvergelijking.</p>
              </div>
              <div className="flex size-11 items-center justify-center rounded-sm bg-mint text-teal">
                <Battery className="size-5" />
              </div>
            </div>
            <Range label="Bruikbare batterijcapaciteit" value={`${capacity} kWh`} min={2} max={20} current={capacity} onChange={setCapacity} />
            <Range label="Avond- en nachtverbruik" value={`${evening} kWh`} min={2} max={20} current={evening} onChange={setEvening} />
            <div className="mt-6">
              <span className="text-xs uppercase tracking-wider text-muted">Theoretisch aandeel dat een volle batterij kan dekken</span>
              <div className="mt-2 font-display text-5xl tabular-nums">{cover}%</div>
              <p className="mt-3 text-sm text-muted">{capacity} kWh opslag tegenover {evening} kWh avond- en nachtverbruik.</p>
            </div>
            <p className="mt-4 text-xs text-muted">
              Vereenvoudigde vergelijking, zonder laadverliezen of vermogensgrenzen. Geen dimensioneringsadvies.
            </p>
            <Button asChild variant="ghost" className="mt-6 w-full">
              <Link to="/aanvragen">Laat je situatie beoordelen</Link>
            </Button>
          </section>
        </div>
      </Wrap>
    </main>
  );
}

function Range({
  label,
  value,
  min,
  max,
  step = 1,
  current,
  onChange,
}: {
  label: string;
  value: string;
  min: number;
  max: number;
  step?: number;
  current: number;
  onChange: (n: number) => void;
}) {
  return (
    <label className="mb-5 block text-sm">
      <span className="mb-2 flex justify-between">
        {label} <output className="tabular-nums font-semibold">{value}</output>
      </span>
      <input type="range" min={min} max={max} step={step} value={current} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-teal" />
    </label>
  );
}
