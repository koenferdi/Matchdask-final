import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, Wrap } from "@/components/site-shell";
import { NewsletterForm } from "@/components/newsletter-form";

export const Route = createFileRoute("/nieuwsbrief")({
  component: Nieuwsbrief,
  head: () => ({
    meta: [{ title: "Nieuwsbrief — Matchdesk" }],
  }),
});

function Nieuwsbrief() {
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap className="max-w-xl">
        <PageIntro kicker="Nieuwsbrief" title="Blijf bij zonder ruis.">
          Af en toe een helder stuk over wonen, energie en 1:1-matching. Geen aanbiedingenstorm, geen doorsturen naar installateurs.
        </PageIntro>
        <div className="rounded-lg border border-line bg-white p-6">
          <NewsletterForm />
        </div>
      </Wrap>
    </main>
  );
}
