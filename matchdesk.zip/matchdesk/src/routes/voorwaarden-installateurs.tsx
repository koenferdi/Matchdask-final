import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, Wrap } from "@/components/site-shell";
import { CONTACT } from "@/lib/matchdesk";

export const Route = createFileRoute("/voorwaarden-installateurs")({
  component: VoorwaardenInstallateurs,
});

function VoorwaardenInstallateurs() {
  return (
    <main className="bg-paper py-16 text-ink">
      <Wrap className="max-w-3xl">
        <PageIntro kicker="Installateurs · versie 1.3 · 12 september 2026" title="Voorwaarden voor installateurs">
          Samenwerking tussen Matchdesk en partners. Matchdesk bemiddelt, installeert niet.
        </PageIntro>
        <article className="space-y-6 text-sm leading-7 text-muted [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:text-ink">
          <h2>Exclusiviteit</h2>
          <p>Een aanvraag gaat naar precies één partner. Reageer je niet binnen het responsevenster, dan mag Matchdesk één andere partner zoeken.</p>
          <h2>Commissie</h2>
          <p>
            Eerste gewonnen klus via Matchdesk: €0. Daarna 10% van de dealwaarde, tot max. €400 bij panelen en €600 bij batterij of combinatie. Geen abonnement.
          </p>
          <h2>Contact met huiseigenaren</h2>
          <p>
            Gegevens alleen gebruiken voor die ene aanvraag. Bellen mag uitsluitend met uitdrukkelijke toestemming van de huiseigenaar.
          </p>
          <p>
            Vragen: <a className="text-teal" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>.
          </p>
        </article>
      </Wrap>
    </main>
  );
}
