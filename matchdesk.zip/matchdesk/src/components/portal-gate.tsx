import type { ReactNode } from "react";
import { SignInGate } from "@/lib/auth/gates";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Wrap } from "@/components/site-shell";
import type { AuthRole } from "@/components/auth-form";

export function PortalGate({ children, role = "klant" }: { children: ReactNode; role?: AuthRole }) {
  return (
    <SignInGate
      fallback={
        <main className="bg-paper py-16 text-ink">
          <Wrap>
            <h1 className="font-display text-3xl">Eerst een account.</h1>
            <p className="mt-3 max-w-lg text-muted">
              {role === "bedrijf"
                ? "Het bedrijfsportaal is persoonlijk. Meld je bedrijf aan of log in met e-mail of Google."
                : "Het klantportaal is persoonlijk. Maak een account of log in met e-mail of Google."}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/login" search={{ mode: "aanmelden", role }}>
                  {role === "bedrijf" ? "Bedrijf aanmelden" : "Account maken"}
                </Link>
              </Button>
              <Button asChild variant="ghost">
                <Link to="/login" search={{ mode: "inloggen", role }}>
                  Inloggen
                </Link>
              </Button>
            </div>
          </Wrap>
        </main>
      }
    >
      {children}
    </SignInGate>
  );
}
