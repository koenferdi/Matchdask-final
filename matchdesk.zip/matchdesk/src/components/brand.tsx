import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/cn";

export function Brand({ className, inverted }: { className?: string; inverted?: boolean }) {
  return (
    <Link
      to="/"
      aria-label="Matchdesk home"
      className={cn(
        "inline-flex items-center gap-2.5 font-display text-[28px] font-bold tracking-[-1.3px]",
        inverted ? "text-paper" : "text-ink",
        className,
      )}
    >
      <svg viewBox="0 0 32 32" className="size-[31px]" aria-hidden="true">
        <path
          d="M2 26V6h6l8 11L24 6h6v20h-6V16l-8 11-8-11v10z"
          fill="currentColor"
        />
      </svg>
      matchdesk
      <span className="-ml-2 text-bright">.</span>
    </Link>
  );
}
