import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useMatchdesk } from "@/lib/store";
import { cn } from "@/lib/cn";

export function NewsletterForm({ inverted = false }: { inverted?: boolean }) {
  const subscribe = useMatchdesk((s) => s.subscribe);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.includes("@") || email.length < 5) {
      setError("Vul een geldig e-mailadres in.");
      return;
    }
    subscribe(email, name);
    setDone(true);
    setError("");
  }

  if (done) {
    return (
      <p className={cn("text-sm leading-7", inverted ? "text-mint" : "text-teal")}>
        Gelukt. Je ontvangt berichten over wonen, energie en 1:1-matching — geen aanbiedingenstorm.
      </p>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <label className="sr-only" htmlFor="nl-name">
        Naam
      </label>
      <input
        id="nl-name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Naam (optioneel)"
        className={cn("field-input", inverted && "field-input-invert")}
        autoComplete="name"
      />
      <label className="sr-only" htmlFor="nl-email">
        E-mail
      </label>
      <input
        id="nl-email"
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="E-mailadres"
        className={cn("field-input", inverted && "field-input-invert")}
        autoComplete="email"
      />
      {error ? <p className="text-sm text-amber">{error}</p> : null}
      <Button type="submit" variant={inverted ? "mint" : "default"} className="w-full sm:w-auto">
        Houd me op de hoogte
      </Button>
      <p className={cn("text-xs leading-6", inverted ? "text-mint/50" : "text-muted")}>
        Maximaal een paar keer per jaar. Uitschrijven kan altijd. We sturen je gegevens niet naar installateurs.
      </p>
    </form>
  );
}
